ASDF, the tkinter game, is a single player "adventure themed" game.

IMPORTANT !!!!!

Features:
the game autosave the player level, life, score, and position every seconds in the character_saves.txt
the player score is saved in the player_records.txt and added to the leaderboard only if the player wins or lose
please only resize the window in menu page 
the game is pep8 compliant according to http://pep8online.com
the images used in the game are from vector stock with standard license

Objective:
Only eat the yellow cube to gain score, and increase character size to be able to eat more yellow cubes.
If touch any color cube other than yellow, the character lose life, at the rate of maximum 2 life per seconds if touched enemy multiple times.
There are 12 level of game so far, each level have a unique type of enemy that have a 10% chance to spawn.
There are four characters in the game, each with it's own unique strength and weakness

Keybindings:
Mouse-Left-Click ---- to select character and to create new game or continue
Left-arrow,Right-arrow... ---- to controll character movement
Letter-b ----to enter the boss mode, where you appear to be doing something productive
space ---- to pause the game and drink a cup of tea

Cheatcodes:
Letter-c ---- to be able to eat any enemy, ignoring their color code
Letter-h ---- to increase totally life by one
Letter-s ---- to increase the final score by 10

Potential Issues:
the text size for the game in the lab machine may not be correctly displayed
if you encountered a bug during you run, (i.e. find cube escaping the boarder, that shouldn't happen but if so please quit the game and reload by the continue button in the menu
If any bug appeared please email guocongyun1218@hotmail.com

SUPER IMPORTANT:

Merry Christmas !!!

NOT VERY IMPORTANT:

Enemy types:
NormalEnemy ---- color: purple ---- description: just normal enemy
WeakEnemy ---- color: yellow ---- description: please only touch/eat him
HorizontalEnemy---- color: red---- description: move horizontally faster
VerticalEnemy---- color: orange---- description: move vertically faster
TallEnemy---- color: light purple---- description: normal enemy but with horizontal rectangular shape
WideEnemy---- color: dark purple ---- description: normal enemy but with vertical rectangular shape
InvisibleEnemy---- color: none ---- description: you can only see it's boarder
BetterEnemy---- color: redish pink---- description: move faster in all direction than normal enemy
StupidEnemy---- color: white---- description: don't move and try to confuse you
TrapEnemy---- color: none---- description: don't move and almost invisible
CrazyEnemy---- color: pink ---- description: move super fast in all direction
TrickyEnemy---- color: light yellow---- description: try to confuse you that he is the food
WeirdEnemy---- color: grey---- description: either only move horizontally really fast or vertically really fast


